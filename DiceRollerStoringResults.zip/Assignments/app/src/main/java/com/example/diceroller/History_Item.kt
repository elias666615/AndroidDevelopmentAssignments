package com.example.diceroller

import java.io.Serializable

data class History_Item(var numList: List<Int>, var rollType: String, var rollCounter: Int) : Serializable
