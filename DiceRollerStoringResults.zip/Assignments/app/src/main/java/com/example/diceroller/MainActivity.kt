package com.example.diceroller

import android.content.Intent
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.createBitmap
import org.w3c.dom.Text
import java.io.Serializable
import java.lang.reflect.GenericArrayType
import java.util.*
import kotlin.collections.ArrayList
import kotlin.random.Random

public class MainActivity : AppCompatActivity() {

    object Singleton{
        init {
        }
        var list = ArrayList<History_Item>()
        fun deleteAll(){
            list.clear()
        }
    }


    private var rollcounter = 1
    private var diceRolled = 0
    private var urlList = listOf<Int>(R.drawable.dice1, R.drawable.dice2, R.drawable.dice3, R.drawable.dice4, R.drawable.dice5, R.drawable.dice6)
    private var Histroy_List = ArrayList<History_Item>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val tvCounter = findViewById<TextView>(R.id.tvRollCounter)
        tvCounter.setText(this.rollcounter.toString())
    }

    fun onIncrementCounter(btnIncrement: View) {
        val btnDecrement = findViewById<Button>(R.id.btnDecrement)
        val tvCounter = findViewById<TextView>(R.id.tvRollCounter)
        this.rollcounter++
        if(this.rollcounter >= 4) {
            btnIncrement.setEnabled(false)
        }
        else if(this.rollcounter > 1) {
            btnDecrement.setEnabled(true)
        }
        tvCounter.setText(this.rollcounter.toString())
    }

    fun onDecrementCounter(btnDecrement: View) {
        val btnIncrement = findViewById<Button>(R.id.btnIncrement)
        val tvCounter = findViewById<TextView>(R.id.tvRollCounter)
        this.rollcounter--
        if(this.rollcounter <= 1) {
            btnDecrement.setEnabled(false)
        }
        else if(this.rollcounter < 4) {
            btnIncrement.setEnabled(true)
        }
        tvCounter.setText(this.rollcounter.toString())
    }

    fun rollAllDice(btnRollAllDice: View) {
        var numbers = mutableListOf<Int>()
        var counter = 0
        var ImageList = listOf<ImageView>(findViewById(R.id.imgDice1), findViewById(R.id.imgDice2), findViewById(R.id.imgDice3), findViewById(R.id.imgDice4))
        for(image in ImageList) {
            image.visibility = View.INVISIBLE
        }
        while(counter < this.rollcounter) {
            val diceNumber = Random.nextInt(1, 7)
            numbers.add(diceNumber)
            ImageList[counter].setImageResource(this.urlList[diceNumber-1])
            ImageList[counter].visibility = View.VISIBLE
            counter++
        }
        this.Histroy_List.add(History_Item(numbers, "Roll All Dice", this.rollcounter))
        Singleton.list.add(History_Item(numbers, "Roll All Dice", this.rollcounter))
        this.diceRolled = 0
    }

    fun rollNextDice(btnRollNextDice: View) {
        var numbers = mutableListOf<Int>()
        var ImageList = listOf<ImageView>(findViewById(R.id.imgDice1), findViewById(R.id.imgDice2), findViewById(R.id.imgDice3), findViewById(R.id.imgDice4))
        if(this.diceRolled == 0 || this.diceRolled >= this.rollcounter) {
            for(image in ImageList) {
                image.visibility = View.INVISIBLE
            }
            this.diceRolled = 0
        }
        var diceNumber = Random.nextInt(1, 7)
        numbers.add(diceNumber)
        ImageList[diceRolled].setImageResource(this.urlList[diceNumber-1])
        ImageList[diceRolled].visibility = View.VISIBLE
        this.Histroy_List.add(History_Item(numbers, "Roll Next Dice", this.rollcounter))
        Singleton.list.add(History_Item(numbers, "Roll Next Dice", this.rollcounter))
        this.diceRolled++
    }

    fun openHistory(btnHistory: View) {
        val intent = Intent(this, History::class.java)
        intent.putExtra("history", this.Histroy_List)
        startActivity(intent)
    }
}