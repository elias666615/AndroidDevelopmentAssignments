package com.example.diceroller

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class History : AppCompatActivity() {

    private lateinit var newRecyclerView: RecyclerView
    private lateinit var newArrayList: ArrayList<History_Item>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.history_list)

        newRecyclerView = findViewById(R.id.rvHistoryList)
        newRecyclerView.layoutManager = LinearLayoutManager(this)
        newRecyclerView.setHasFixedSize(true)
        newArrayList = intent.getSerializableExtra("history") as ArrayList<History_Item>
        newRecyclerView.adapter = MyAdapter(newArrayList)
        val adapter = MyAdapter(newArrayList)

        val swipegesture = object : SwipeGesture() {
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                when(direction) {
                    ItemTouchHelper.LEFT -> {
                        adapter.deleteItem(viewHolder.adapterPosition)
                    }
                }
                super.onSwiped(viewHolder, direction)
            }
        }

        val touchHelper = ItemTouchHelper(swipegesture)
        touchHelper.attachToRecyclerView(newRecyclerView)
    }

    fun deleteAll(btnDeleteAll: View) {
        this.newArrayList = ArrayList<History_Item>()
        newRecyclerView.adapter = MyAdapter(newArrayList)
    }
}